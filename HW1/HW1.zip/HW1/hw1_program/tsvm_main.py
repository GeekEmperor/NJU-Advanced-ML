import numpy as np


class TSVM:
    def fit(self, X_l, y, X_u):
        """
        训练函数
        :param X_l: 有标记数据的特征
        :param y: 有标记数据的标记
        :param X_u: 无标记数据的特征
        """
        pass

    def predict(self, X):
        """
        预测函数
        :param X: 预测数据的特征
        :return: 数据对应的预测值
        """
        pass


def load_data():
    label_X = np.loadtxt('label_X.csv', delimiter=',')
    label_y = np.loadtxt('label_y.csv', delimiter=',').astype(np.int)
    unlabel_X = np.loadtxt('unlabel_X.csv', delimiter=',')
    unlabel_y = np.loadtxt('unlabel_y.csv', delimiter=',').astype(np.int)
    test_X = np.loadtxt('test_X.csv', delimiter=',')
    test_y = np.loadtxt('test_y.csv', delimiter=',').astype(np.int)
    return label_X, label_y, unlabel_X, unlabel_y, test_X, test_y


if __name__ == '__main__':
    label_X, label_y, unlabel_X, unlabel_y, test_X, test_y \
        = load_data()
    tsvm = TSVM()
    tsvm.fit(label_X, label_y, unlabel_X)
